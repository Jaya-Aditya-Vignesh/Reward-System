from app import db
from datetime import datetime, timedelta

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    points = db.Column(db.Integer, default=0)
    redeemed_coupons = db.relationship('RedeemedCoupon', backref='user', lazy=True)

class Coupon(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    description = db.Column(db.String(255), nullable=False)
    points_required = db.Column(db.Integer, nullable=False)
    expiry_date = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"<Coupon {self.code}>"

class RedeemedCoupon(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    coupon_id = db.Column(db.Integer, db.ForeignKey('coupon.id'), nullable=False)
    redeemed_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_used = db.Column(db.Boolean, default=False)
    coupon = db.relationship('Coupon', backref='redeemed_coupons')
    def __repr__(self):
        return f"<RedeemedCoupon {self.id}>"