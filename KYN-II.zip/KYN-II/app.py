from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)


# Set a secret key for session management (either from an environment variable or default)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'kn')

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:aditya@localhost/reward_system'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Initialize Flask-Migrate
migrate = Migrate(app, db)

# Import models after initializing db
import models

# Test route (optional)
@app.route('/')
def index():
    return "Reward System App is Running!"

if __name__ == '__main__':
    app.run(debug=True)

