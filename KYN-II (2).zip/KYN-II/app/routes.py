from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import User, Coupon, RedeemedCoupon, db
from datetime import datetime, timedelta

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    user = User.query.first()  # Assume a single user for simplicity
    return render_template('index.html', user=user)

@main_bp.route('/rewards')
def rewards():
    user = User.query.first()
    return render_template('rewards.html', user=user)

@main_bp.route('/coupons')
def coupons():
    coupons = Coupon.query.all()
    return render_template('coupons.html', coupons=coupons)

@main_bp.route('/redeem/<int:coupon_id>', methods=['POST'])
def redeem(coupon_id):
    user = User.query.first()
    coupon = Coupon.query.get(coupon_id)

    if not coupon:
        flash('Coupon not found!', 'danger')
        return redirect(url_for('main.coupons'))

    if user.points < coupon.points_required:
        flash('Not enough points to redeem this coupon!', 'danger')
        return redirect(url_for('main.coupons'))

    user.points -= coupon.points_required
    redeemed_coupon = RedeemedCoupon(coupon_id=coupon.id, user_id=122, redeemed_at=db.func.current_timestamp(),expiry_date=(datetime.utcnow() + timedelta(days=7)))
    db.session.add(redeemed_coupon)
    db.session.commit()
    flash('Redeemed this coupon!', 'success')
    return redirect(url_for('main.rewards'))
